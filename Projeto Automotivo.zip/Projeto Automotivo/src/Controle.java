public class Controle {
    private PilhaChecklist checklist;
    private FilaVeiculo ordemChegada;

    public void verificacao(FilaVeiculo veiculos) {
        NodeChecklist current = checklist.head;
        while(current != null) {
            if(veiculos.head.data.getPassageiros().amount == current.data) {
                System.out.println("Parametro de passageiros: Aprovado");
            }
            else {
                System.out.println("Parametro de passa");
            }
            current = current.next;
        }
    }
}
