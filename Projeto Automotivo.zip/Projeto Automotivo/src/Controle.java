public class Controle {
    private Pilha checklist;
    private Fila ordemChegada;

    //ainda nao sei direito como implementar essa parte
    public boolean verificacao() {
        Node current = checklist.head;
        while() {
        }
        if() {return true;}
        else {return false;}
    }
}
