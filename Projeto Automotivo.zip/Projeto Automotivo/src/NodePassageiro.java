public class NodePassageiro {
    String data;
    NodePassageiro next, prev;

    public NodePassageiro(String data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}
