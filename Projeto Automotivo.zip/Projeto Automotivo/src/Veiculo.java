public class Veiculo {
    private String descricao;
    private Fila passageiros;

    Veiculo(String descricao, Fila passageiros) {
        this.descricao = descricao;
        this.passageiros = passageiros;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Fila getPassageiros() {
        return passageiros;
    }

    public void setPassageiros(Fila passageiros) {
        this.passageiros = passageiros;
    }
}