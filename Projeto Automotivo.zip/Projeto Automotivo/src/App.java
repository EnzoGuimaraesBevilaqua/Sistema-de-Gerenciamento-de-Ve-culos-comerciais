import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);
        FilaVeiculo veiculos = new FilaVeiculo();
        PilhaChecklist testes = new PilhaChecklist(3);
        testes.push(4);
        testes.push(4);
        testes.push(5);
        Controle controle = new Controle();
        int escolha = 0;
        String descricao;
        String nomePassageiro;
        int rodas;
        int portas;
        String lixo;

        while(true) {
            if(veiculos.head == null) {
                System.out.println("Sem Veiculos na fila");
            }
            else {
                System.out.println("Veiculos na fila: " + veiculos.amount);
            }
            
            System.out.println("\n1- Inserir veiculo a fila");
            System.out.println("2- Fazer verificacao do veiculo");
            System.out.println("0- Encerrar\n");
            escolha = input.nextInt();
            lixo = input.nextLine();
            
            if(escolha == 1) {
                System.out.println("Abrindo terminal de cadastro\n");
                System.out.println("Descricao do veiculo:");
                descricao = input.nextLine();
                System.out.println("Numero de rodas: ");
                rodas = input.nextInt();
                System.out.println("Numero de portas: ");
                portas = input.nextInt();
                lixo = input.nextLine();
                FilaPassageiro passageiros = new FilaPassageiro();
                while(true) {
                    System.out.println("Nome do passageiro: ");
                    nomePassageiro = input.nextLine();
                    passageiros.addPassageiro(nomePassageiro);
                    System.out.println("Adicionar outro passageiro ?(3- sim 4-nao)");
                    escolha = input.nextInt();
                    lixo = input.nextLine();
                    if(escolha == 3) {
                    
                    }
                    else if(escolha == 4) {
                        veiculos.addVeiculo(new Veiculo(descricao, passageiros, rodas, portas));
                        break;
                    }
                } 
            }
            else if(escolha == 2) {
                System.out.println("Iniciando verificacao\n");
            }
            else if(escolha == 0) {
                System.out.println("Encerrando...\n");
                break;
            }
        }
        input.close();
    }
}
