public class NodeOrdemChegada {
    Veiculo data;
    NodeOrdemChegada next, prev;

    public NodeOrdemChegada(Veiculo data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}
