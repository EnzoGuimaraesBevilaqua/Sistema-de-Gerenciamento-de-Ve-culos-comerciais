public class Pilha {
    Node head;
    int size, amount;
    
    Pilha(int size) {
        this.head = null;
        this.size = size;
    }

    public void push(int data) {
        if(amount >= size) {
            System.out.println("Nao se pode adicionar mais elementos, a pilha esta cheia");
        }
        else {
            Node newNode = new Node(data);

            if(head == null) {
                head = newNode;
            }
            else {
                newNode.next = head;
                head = newNode;
            }
            amount++;
        }
    }

    public void pop() {
        if(amount < 1) {
            System.out.println("A pilha nao possui elementos para serem retirados");
        }
        else {
            if(head == null) {
                return;
            }

            Node temp = head;
            head = head.next;
            temp.next = null;
            amount--;
        }
    }

    public void peek() {
        if(head == null) {
            System.out.println("Nao existe elemento na pilha");
        }
        else {
            System.out.println(this.head.data + "\n");
        }
    }

    public boolean isEmpty() {
        if(head == null) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean isFull() {
        if(amount == size) {
            return true;
        }
        else {
            return false;
        }
    }

    public void traverseForward() {
        Node current = head;

        while(current != null) {
            System.out.println(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
