public class NodeChecklist {
    int data;
    NodeChecklist next;

    public NodeChecklist(int data) {
        this.data = data;
        this.next = null;
    }
}
